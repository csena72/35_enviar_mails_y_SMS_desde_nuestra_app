const nodemailer = require('nodemailer')

const asunto = process.argv[2]
const mensaje = process.argv[3]
const to = process.argv[4]
const adjunto = process.argv[5]

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'cursonodeav@gmail.com',
        pass: 'ppppppppppppppppp'
    }
});

const mailOptions = {
    from: 'Módulo Node.js',
    to: to,
    subject: asunto,
    html: mensaje,
    attachments: [
        {   // filename and content type is derived from path
            path: adjunto? adjunto : ''
        }
    ]    
}

console.log(mailOptions)

transporter.sendMail(mailOptions, (err, info) => {
    if(err) {
        console.log(err)
        return err
    }
    console.log(info)
})



