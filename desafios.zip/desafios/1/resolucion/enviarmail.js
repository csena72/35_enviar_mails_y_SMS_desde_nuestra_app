const nodemailer = require('nodemailer')

const asunto = process.argv[2];
const mensaje = process.argv[3];

const transporter = nodemailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
        user: 'ford.blanda@ethereal.email',
        pass: 'pppppppppppppppppp'
    }
});

const mailOptions = {
    from: 'Módulo Node.js',
    to: 'ford.blanda@ethereal.email',
    subject: asunto,
    html: mensaje
}

transporter.sendMail(mailOptions, (err, info) => {
    if(err) {
        console.log(err)
        return err
    }
    console.log(info)
})
